dhtmlxToolbar v.2.6 Standard edition build 110318 (with IE9 fix applied)

(c) DHTMLX Ltd. 