//v.2.6 build 100722

/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
You allowed to use this component or parts of it under GPL terms
To use it on other terms or get Professional edition of the component please contact us at sales@dhtmlx.com
*/

 
 dataProcessor.prototype.setOnAfterUpdate = function(ev){this.attachEvent("onAfterUpdate",ev);};dataProcessor.prototype.enableDebug = function(mode){};dataProcessor.prototype.setOnBeforeUpdateHandler=function(func){this.attachEvent("onBeforeDataSending",func);};
//v.2.6 build 100722

/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
You allowed to use this component or parts of it under GPL terms
To use it on other terms or get Professional edition of the component please contact us at sales@dhtmlx.com
*/